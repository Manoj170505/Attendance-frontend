import ZKLib from 'node-zklib';
import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, 'config.json');
const CACHE_PATH = path.join(__dirname, 'synced_cache.json');

// Load Configuration
let config = {
  deviceIp: '192.168.137.200',
  devicePort: 4370,
  deviceSerial: 'NFZ8235301513',
  cloudApiUrl: 'https://attendance-backend-production-48ca.up.railway.app',
  pollIntervalSeconds: 3
};

if (fs.existsSync(CONFIG_PATH)) {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    config = { ...config, ...JSON.parse(raw) };
  } catch (err) {
    console.error('⚠️ Could not parse config.json, using defaults:', err.message);
  }
}

// Load Cache of Synced Punches to prevent duplicate submissions
let syncedCache = new Set();
if (fs.existsSync(CACHE_PATH)) {
  try {
    const raw = fs.readFileSync(CACHE_PATH, 'utf8');
    const arr = JSON.parse(raw);
    syncedCache = new Set(arr);
  } catch (err) {
    syncedCache = new Set();
  }
}

function saveCache() {
  try {
    // Keep cache bounded to last 5,000 entries
    const arr = Array.from(syncedCache).slice(-5000);
    fs.writeFileSync(CACHE_PATH, JSON.stringify(arr, null, 2));
  } catch (err) {
    console.error('⚠️ Error saving synced cache:', err.message);
  }
}

console.log('================================================================');
console.log('🚀 UNIVERSAL BIOMETRIC LOCAL SYNC AGENT (eSSL / ZKTeco / BioMax)');
console.log('================================================================');
console.log(`🔒 Target Device IP:    ${config.deviceIp}:${config.devicePort}`);
console.log(`🏷️ Device Serial No:    ${config.deviceSerial}`);
console.log(`☁️ Cloud Server URL:    ${config.cloudApiUrl}`);
console.log(`⏱️ Sync Polling Rate:   Every ${config.pollIntervalSeconds} seconds`);
console.log('================================================================\n');

const zk = new ZKLib(config.deviceIp, config.devicePort, 10000, 4000);

let isConnected = false;
let isPolling = false;

// Function to send a punch to Railway Cloud REST API
async function pushPunchToCloud(record) {
  try {
    const employeeId = String(record.deviceUserId || record.userId || record.pin || record.user_sn || record.uid);
    const punchTime = record.recordTime || record.timestamp || record.time || new Date();
    const stateCode = String(record.recordType || record.status || record.state || 0);

    const stateMap = {
      '0': 'CHECK_IN',
      '1': 'CHECK_OUT',
      '2': 'BREAK_OUT',
      '3': 'BREAK_IN',
      '4': 'OVERTIME_IN',
      '5': 'OVERTIME_OUT'
    };

    const payload = {
      deviceSerial: config.deviceSerial,
      employeeId,
      timestamp: new Date(punchTime).toISOString(),
      state: stateMap[stateCode] || 'CHECK_IN',
      punchType: 'FINGERPRINT',
      rawData: `AGENT_PUNCH: ${employeeId}\t${new Date(punchTime).toISOString()}\t${stateMap[stateCode] || 'CHECK_IN'}`
    };

    const response = await axios.post(`${config.cloudApiUrl.replace(/\/$/, '')}/api/attendance/punch`, payload, {
      timeout: 15000,
      headers: { 'Content-Type': 'application/json' }
    });

    if (response.data && response.data.success) {
      console.log(`✅ [SYNCED TO CLOUD] Employee PIN: ${employeeId} | ${new Date(punchTime).toLocaleTimeString()} | State: ${payload.state}`);
      return true;
    }
  } catch (err) {
    console.error(`❌ [CLOUD SYNC ERROR] Failed to push punch:`, err.response?.data?.error || err.message);
    return false;
  }
  return false;
}

// Function to send Heartbeat to Cloud Server
async function sendHeartbeat() {
  try {
    await axios.get(`${config.cloudApiUrl.replace(/\/$/, '')}/iclock/cdata?SN=${config.deviceSerial}`, {
      timeout: 10000
    });
  } catch (err) {
    // Silent heartbeat fail
  }
}

// Sync Loop
async function pollAttendanceLogs() {
  if (isPolling || !isConnected) return;
  isPolling = true;

  try {
    const logs = await zk.getAttendances();

    if (logs && logs.data && Array.isArray(logs.data)) {
      let newPunches = 0;

      for (const log of logs.data) {
        const uniqueKey = `${config.deviceSerial}_${log.deviceUserId}_${new Date(log.recordTime).getTime()}`;

        if (!syncedCache.has(uniqueKey)) {
          const success = await pushPunchToCloud(log);
          if (success) {
            syncedCache.add(uniqueKey);
            newPunches++;
          }
        }
      }

      if (newPunches > 0) {
        saveCache();
        console.log(`✨ [BATCH COMPLETE] Synced ${newPunches} new biometric punch(es) to cloud dashboard.\n`);
      }
    }
  } catch (err) {
    console.warn(`⚠️ [POLL WARNING] ${err.message}`);
    // If connection dropped, mark disconnected to trigger reconnect
    if (err.message && (err.message.includes('timeout') || err.message.includes('closed') || err.message.includes('ECONNRESET'))) {
      isConnected = false;
    }
  } finally {
    isPolling = false;
  }
}

// Main Connection Routine
async function connectToDevice() {
  while (true) {
    if (!isConnected) {
      try {
        console.log(`📡 Connecting to eSSL / ZKTeco machine at ${config.deviceIp}:${config.devicePort}...`);
        await zk.createSocket();
        isConnected = true;
        console.log(`🟢 [CONNECTED TO DEVICE] Ready to capture live attendance punches!\n`);

        // Send first heartbeat to cloud
        await sendHeartbeat();
      } catch (err) {
        console.error(`🔴 [CONNECT FAILED] Could not reach machine at ${config.deviceIp}:${config.devicePort} (${err.message}). Retrying in 5s...`);
        isConnected = false;
        try { await zk.disconnect(); } catch (e) {}
      }
    }

    if (isConnected) {
      await pollAttendanceLogs();
      await sendHeartbeat();
    }

    await new Promise((resolve) => setTimeout(resolve, config.pollIntervalSeconds * 1000));
  }
}

// Start Agent
connectToDevice().catch(console.error);

// Clean exit handlers
process.on('SIGINT', async () => {
  console.log('\n🛑 Stopping Biometric Sync Agent...');
  try { await zk.disconnect(); } catch (e) {}
  process.exit(0);
});
